# DroidPanel

Free, open-source, ad-free, privacy-first Android diagnostics app.
Kotlin · Jetpack Compose · Material 3 · Gradle Kotlin DSL · MVVM.

## Status: Phase 1 (shell)

Done: Gradle/Android project, monochrome theme, edge-to-edge, navigation with transitions,
dashboard shell (real device model + Android version from `android.os.Build`), a detail screen
for each of the 12 planned modules, unit tests, CI workflow.

**Not done yet:** all measurements (RAM, battery, storage, CPU, ...), the particle visualization,
history graphs. Module screens clearly say "Not implemented yet" and show no sample data.

**Build status:** not verified locally. The first CI run is the real test; fix any compile errors it reports.

## Build

GitHub Actions (`.github/workflows/build.yml`) runs unit tests and `assembleDebug`, then uploads
`droidpanel-debug-apk` as a workflow artifact. Actions -> latest run -> Artifacts.

Locally (Gradle 8.10.2+, JDK 17, Android SDK 35): `gradle assembleDebug`.
The Gradle wrapper JAR is not included; see `gradle/wrapper-NOTE.txt`.

## Roadmap

2 memory/storage/battery data · 3 particle visualization · 4 CPU/GPU/display/thermal/sensors ·
5 network/apps/device/camera/audio · 6 history, tests, accessibility, performance · 7 release CI.

Release signing: `docs/RELEASE_SIGNING.md`. License: MIT.
